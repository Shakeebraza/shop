<!-- Footer -->
<footer class="footer">
    <div class="footer-content">
        &copy; CardVault 2025
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" charset="utf-8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/qrious/dist/qrious.min.js"></script>
<script>
$(document).ready(function() {
    $('#userDropdownToggle').click(function() {
        $('#userDropdownMenu').toggle('fast');
    });
});
</script>




